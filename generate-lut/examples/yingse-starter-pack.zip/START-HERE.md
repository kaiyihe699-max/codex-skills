# 映色演示包 · Start here

这里包含三张开放摄影样本、已生成的 LUT/配方/对比图及完整运行脚本。
素材不是 Karl 拍摄、不是客户作品，也不代表机构或人物背书。来源见 examples/SOURCES.md。

## 先看结果

打开 examples/gallery.jpg，或进入 examples/looks/ 查看每组 preview-comparison.png。
对比图左原图、右 LUT 效果。每组 look.cube 都以 100% 应用，创意强度已经写入。

## 自己复现（在本文件所在目录运行）

python -m pip install -r requirements.txt
python scripts/doctor.py
python scripts/run_demo.py --example portrait --output-dir delivery/first-look

其他样例：把 portrait 换成 still-life 或 twilight，并使用新的输出目录。

## 用自己的照片

python scripts/create_lut_package.py --look warm-film --strength 0.65 --input my-photo.jpg --output-dir delivery/my-look

## 重建已保存配方

python scripts/create_lut_package.py --recipe examples/looks/portrait/recipe.json --input examples/inputs/portrait.png --output-dir delivery/replayed

Windows 若没有 python 命令可用 py -3。需要 Python 3.10+ 和带 LittleCMS 的 Pillow。
已有输出不会覆盖。默认入口用于普通 8-bit sRGB 照片，RAW/Log/HDR 请先按完整说明处理。
更多说明见 README.md；运行逻辑见 SKILL.md。没有联网、照片上报或额外 API key 的要求。
